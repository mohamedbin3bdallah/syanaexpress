<!DOCTYPE html>
<html lang="en">
<head>
  <title>Payment Successfully</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body style="background:#fff;">
<div class="container">
  <div class="row">
   <div class="col-lg-12">
      <div style="text-align: center; background:#fff;">
        	<img class="img-responsive" src="<?php echo base_url('assets/images/success.jpg'); ?>">
      </div>
    </div> 
  </div>
</div>
</body>
</html>
