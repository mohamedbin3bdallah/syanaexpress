 <!-- partial -->
<div class="main-panel">
  <div class="content-wrapper">
    <div class="row">
       <div class="col-lg-12 grid-margin stretch-card">
	        <div class="card">
	          <div class="card-body">
	            <div style="text-align: center;">
	            	<img src="<?php echo base_url('assets/images/payment_failed.jpg'); ?>">
	            	<p><a href="<?php echo base_url('index.php/Admin/requestAmount') ?>">Back to Payment request</a></p>
	            </div>

	            </div>
	        </div>
        </div> 
    </div>     
  </div>    