<?php
	header('Location: '.$url.'');
?>