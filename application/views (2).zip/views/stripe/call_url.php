<?php $id=1; $user_id=9;?>
<a class="btn btn-white" href="<?php echo base_url('Stripe/Payment/make_payment');?>/<?php echo $id; ?>/<?php echo $user_id ?>">Make Payment</a>