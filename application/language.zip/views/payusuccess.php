 <!-- partial -->
<div class="main-panel">
  <div class="content-wrapper">
    <div class="row">
       <div class="col-lg-12 grid-margin stretch-card">
	        <div class="card">
	          <div class="card-body">
	            <div style="text-align: center;">
	            	<img src="<?php echo base_url('assets/images/thanks.png'); ?>">
	            	<h2><?php echo get_phrase('your_payment_has_been_successfully'); ?></h2>
	            	<a href="<?php echo base_url('index.php/Admin/requestAmount') ?>">Back to Payment request</a>
	            </div>

	            </div>
	        </div>
        </div> 
    </div>     
  </div>    