<?php
 $lang['language_key'] = 'The actual message to be shown';

?>