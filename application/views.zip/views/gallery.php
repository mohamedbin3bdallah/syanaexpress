<section class="content">
        <div class="container-fluid">
            <!-- Image Gallery -->
            <div class="block-header">
                <h2>
                    SHOW DATA
                </h2>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                GALLERY
                            </h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a aria-expanded="false" aria-haspopup="true" role="button" data-toggle="dropdown" class="dropdown-toggle" href="javascript:void(0);">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);" class=" waves-effect waves-block">Action</a></li>
                                        <li><a href="javascript:void(0);" class=" waves-effect waves-block">Another action</a></li>
                                        <li><a href="javascript:void(0);" class=" waves-effect waves-block">Something else here</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="list-unstyled row clearfix" id="aniimated-thumbnials">
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/1.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-1.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/2.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-2.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/3.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-3.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/4.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-4.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/5.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-5.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/6.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-6.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/7.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-7.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/8.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-8.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/9.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-9.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/10.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-10.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/11.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-11.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/12.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-12.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/13.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-13.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/14.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-14.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/15.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-15.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/16.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-16.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/17.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-17.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/18.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-18.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/19.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-19.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-sm-3 col-xs-6">
                                    <a data-sub-html="Demo Description" href="<?php echo base_url();?>assets/images/image-gallery/20.jpg">
                                        <img src="<?php echo base_url();?>assets/images/image-gallery/thumb/thumb-20.jpg" class="img-responsive thumbnail">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>